const scriptURL = 'https://script.google.com/macros/s/AKfycbzamEGk6PQfOJpBy8vc4PxYtjzYt8SReuoz6dJRBB6sIYD3xTSD0C2eznPEWOY64S1-/exec'

const form = document.forms['contact-form']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  .then(response => alert("Thank you!  submitted successfully.please proceed to pay" ))
  .then(() => { window.location.reload(); })
  .catch(error => console.error('Error!', error.message))
})