const scriptURL ='https://script.google.com/macros/s/AKfycbwrbitI-Ib8fndrj1seCODzWxOepEm72sisoTkhiAq2jb0-GunSqLk2HvEAz4irqT9XLw/exec'

const form = document.forms['google-sheet']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  .then(response => alert("Thank you! your form is submitted successfully." ))
  .then(() => { window.location.reload(); })
  .catch(error => console.error('Error!', error.message))
})