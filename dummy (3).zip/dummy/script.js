const chatContainer = document.getElementById('chatContainer');
const chatBox = document.getElementById('chatBox');
const userInput = document.getElementById('userInput');

function sendMessage(message) {
    if (message) {
        userInput.value = message;
    } else {
        message = userInput.value;
    }
    
    if (message.trim() === '') return;

    appendUserMessage(message);
    processMessage(message);
    userInput.value = '';
}

function appendBotMessage(message) {
    const botMessageElement = document.createElement('div');
    botMessageElement.classList.add('chat-message', 'bot-message');
    botMessageElement.innerHTML = `<p>${message}</p>`;
    chatBox.appendChild(botMessageElement);

    // Scroll to bottom
    chatBox.scrollTop = chatBox.scrollHeight;
}

function appendUserMessage(message) {
    const userMessageElement = document.createElement('div');
    userMessageElement.classList.add('chat-message', 'user-message');
    userMessageElement.innerHTML = `<p>${message}</p>`;
    chatBox.appendChild(userMessageElement);

    // Scroll to bottom
   
chatBox.scrollTop = chatBox.scrollHeight;
}

function processMessage(message) {
    // Convert user message to lowercase for case-insensitive matching
    const lowerCaseMessage = message.toLowerCase();

    // Responses based on keywords or topics
    let reply = '';

    if (lowerCaseMessage.includes('book an appointment')) {
        reply = "To schedule an appointment, please visit our appointments page on our website or call our reception at +123456789.";
    } else if (lowerCaseMessage.includes('emergency')) {
        reply = "If you have a medical emergency, please call emergency services immediately at 911.";
    } else if (lowerCaseMessage.includes('services') || lowerCaseMessage.includes('departments') || lowerCaseMessage.includes('specialties')) {
        reply = "Our hospital offers a wide range of medical services including:\n"
              + "- General Medicine\n"
              + "- Pediatrics\n"
              + "- Surgery\n"
              + "- Cardiology\n"
              + "- Orthopedics\n"
              + "- Oncology\n"
              + "For a complete list, visit our website or contact our reception.";
    } else if(lowerCaseMessage.includes('visiting hours')) {
        reply =  "The visiting hours are 24x7"
    
    }
    
    else {
        reply = "I'm sorry, I don't understand. Please try asking in a different way or visit our website for more information.";
    }

    appendBotMessage(reply);
}

// Event listener for enter key press in input field
userInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});
