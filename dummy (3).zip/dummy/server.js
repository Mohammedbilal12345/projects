const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/appointments', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Could not connect to MongoDB...', err));

// Define Appointment Schema
const appointmentSchema = new mongoose.Schema({
    dateTime: { type: String, unique: true }
});

const Appointment = mongoose.model('Appointment', appointmentSchema);

app.post('/api/book', async (req, res) => {
    const { dateTime } = req.body;

    try {
        const newAppointment = new Appointment({ dateTime });
        await newAppointment.save();
        res.json({ success: true });
    } catch (error) {
        if (error.code === 11000) {
            res.json({ success: false, message: 'This time slot is already booked.' });
        } else {
            res.json({ success: false, message: 'An error occurred. Please try again.' });
        }
    }
});

app.get('/api/booked-slots', async (req, res) => {
    try {
        const appointments = await Appointment.find({});
        const bookedSlots = appointments.map(app => app.dateTime);
        res.json({ success: true, bookedSlots });
    } catch (error) {
        res.json({ success: false, message: 'An error occurred. Please try again.' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
